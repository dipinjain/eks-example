#!/bin/bash
#Set below Environment Variables:
#Execute these commands from the root directory of this solution

export CLUSTER_NAME=prod-cluster
export AWS_REGION=us-east-1

#Ensure that you have set the cluster to Production cluster, if not then use-below command
# aws eks update-kubeconfig --name $CLUSTER_NAME

#Install Helm:
curl -sSL https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 | bash

#AppMesh prequisite:
# Ensure that output inidcating all the checks are passed.
curl -o pre_upgrade_check.sh https://raw.githubusercontent.com/aws/eks-charts/master/stable/appmesh-controller/upgrade/pre_upgrade_check.sh
chmod u+x ./pre_upgrade_check.sh
./pre_upgrade_check.sh

#Add Helm Repo for eks-charts:
helm repo add eks https://aws.github.io/eks-charts

#Apply AppMesh CRD's (CustomResourceDefinitions):
kubectl apply -k "https://github.com/aws/eks-charts/stable/appmesh-controller/crds?ref=master"
kubectl create ns appmesh-system

#Create OIDC:
#https://docs.aws.amazon.com/eks/latest/userguide/enable-iam-roles-for-service-accounts.html

eksctl utils associate-iam-oidc-provider \
    --region=$AWS_REGION \
    --cluster $CLUSTER_NAME \
    --approve


#Create IAM Role this would be used for creating Kubernetes Service Account:
eksctl create iamserviceaccount \
    --cluster $CLUSTER_NAME \
    --namespace appmesh-system \
    --name appmesh-controller \
    --attach-policy-arn  arn:aws:iam::aws:policy/AWSCloudMapFullAccess,arn:aws:iam::aws:policy/AWSAppMeshFullAccess \
    --override-existing-serviceaccounts \
    --approve

#Deploy AppMesh Controller:
helm upgrade -i appmesh-controller eks/appmesh-controller \
    --namespace appmesh-system \
    --set region=$AWS_REGION \
    --set serviceAccount.create=false \
    --set serviceAccount.name=appmesh-controller

#Verify the deployment of the AppMesh Controller:
kubectl get deployment appmesh-controller \
    -n appmesh-system \
    -o json  | jq -r ".spec.template.spec.containers[].image" | cut -f2 -d ':'

#IMPORTANT!!!, switch to the directory which has Yaml files related to Appmesh
#Create Mesh, create YAML file accordingly:

kubectl apply -f application-deployment/AppMesh-config/1_base_app.yaml

# namespace/my-apps configured
# deployment.apps/nginx-frontend created
# deployment.apps/sample-app-v1 created
# service/nginx-frontend created
# service/sample-app-v1 created

kubectl apply -f application-deployment/AppMesh-config/2_meshed_app.yaml

#namespace/my-apps created
#mesh.appmesh.k8s.aws/sample-app created
#virtualnode.appmesh.k8s.aws/nginx-frontend created
#virtualservice.appmesh.k8s.aws/sample-app created
#virtualrouter.appmesh.k8s.aws/sample-app-router created
#virtualnode.appmesh.k8s.aws/sample-app-v1 created
#service/sample-app created

#Restrict the permission to which the AppMesh Controller can modify the VirtualNodes
#Set ACCOUNT Number and save as proxy-auth.json
#IMPORTANT: Resource Section has permission to all the Virtual Nodes across all mesh, remove it in-case the permissions are overly permissive.

cat << EOF > application-deployment/AppMesh-config/proxy-auth.json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "appmesh:StreamAggregatedResources",
            "Resource": [
                "arn:aws:appmesh:us-east-1:504314787509:mesh/sample-app/virtualNode/nginx-frontend_my-apps",
                "arn:aws:appmesh:us-east-1:504314787509:mesh/sample-app/virtualNode/sample-app-v1_my-apps",
                "arn:aws:appmesh:us-east-1:504314787509:mesh/sample-app/virtualNode/sample-app-v2_my-apps",
                "arn:aws:appmesh:us-east-1:504314787509:mesh/sample-app/virtualNode/*",
                "*"
            ]
        }
    ]
}
EOF

#Create IAM Policy based out of above configuration
aws iam create-policy --policy-name appmesh-virtual-nodes-policy --policy-document file://proxy-auth.json


#Create IAM Service Accounts which permissins to "StreamAggregatedResources" of AppMesh
eksctl create iamserviceaccount \
    --cluster $CLUSTER_NAME \
    --namespace my-apps \
    --name my-service-a \
    --attach-policy-arn  arn:aws:iam::504314787509:policy/appmesh-virtual-nodes-policy \
    --override-existing-serviceaccounts \
    --approve

eksctl create iamserviceaccount \
    --cluster $CLUSTER_NAME \
    --namespace my-apps \
    --name my-service-b \
    --attach-policy-arn  arn:aws:iam::504314787509:policy/appmesh-virtual-nodes-policy \
    --override-existing-serviceaccounts \
    --approve

#Mesh the Second service "sample-app-v2"
kubectl apply -f application-deployment/AppMesh-config/3_final_app.yaml
# virtualrouter.appmesh.k8s.aws/sample-app-router configured
# virtualnode.appmesh.k8s.aws/sample-app-v2 created
# deployment.apps/sample-app-v2 unchanged
# service/sample-app-v2 unchanged


#Verify the AppMesh Route, especially verify the weights between "sample-app-v1_my-apps" and "sample-app-v2_my-apps":
aws appmesh describe-route \
    --route-name sample-app-route \
    --virtual-router-name sample-app-router_my-apps \
    --mesh-name sample-app
